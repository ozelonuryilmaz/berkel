//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright (c) ___YEAR___ Berkel IOS Development Team. All rights reserved.[OY-2024]
//

import UIKit

enum ___VARIABLE_moduleName___Builder {
    
    static func generate(with data: ___VARIABLE_moduleName___PassData, 
                         coordinator: I___VARIABLE_moduleName___Coordinator,
                         outputDelegate: ___VARIABLE_moduleName___ViewControllerOutputDelegate?) -> ___VARIABLE_moduleName___ViewController {

        let repository = ___VARIABLE_moduleName___Repository()
        let uiModel = ___VARIABLE_moduleName___UIModel(data: data)
        let viewModel = ___VARIABLE_moduleName___ViewModel(repository: repository, 
                                                           coordinator: coordinator,
                                                           uiModel: uiModel)

        return ___VARIABLE_moduleName___ViewController(viewModel: viewModel,
                                                       outputDelegate: outputDelegate)
    }
}
