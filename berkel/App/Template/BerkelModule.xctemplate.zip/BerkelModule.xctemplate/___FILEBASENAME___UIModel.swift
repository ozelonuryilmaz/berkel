//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright (c) ___YEAR___ Berkel IOS Development Team. All rights reserved.[OY-2024]
//

import UIKit

protocol I___VARIABLE_moduleName___UIModel {

	 init(data: ___VARIABLE_moduleName___PassData)

} 

struct ___VARIABLE_moduleName___UIModel: I___VARIABLE_moduleName___UIModel {

	// MARK: Definitions

	// MARK: Initialize
    init(data: ___VARIABLE_moduleName___PassData) {

    }

    // MARK: Computed Props
}

// MARK: Props
extension ___VARIABLE_moduleName___UIModel {

}
