//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright (c) ___YEAR___ Berkel IOS Development Team. All rights reserved.[OY-2024]
//

import UIKit
import Combine

protocol ___VARIABLE_moduleName___ViewControllerOutputDelegate: AnyObject {

}

final class ___VARIABLE_moduleName___ViewController: JobiBaseViewController / MainBaseViewController / BerkelBaseViewController {

    // MARK: Constants

    // MARK: Inject
    private let viewModel: I___VARIABLE_moduleName___ViewModel
    private weak var outputDelegate: ___VARIABLE_moduleName___ViewControllerOutputDelegate? = nil

    // MARK: IBOutlets

    // MARK: Constraints Outlets
    
    // MARK: Initializer
    init(viewModel: I___VARIABLE_moduleName___ViewModel,
         outputDelegate: ___VARIABLE_moduleName___ViewControllerOutputDelegate?) {
        self.viewModel = viewModel
        self.outputDelegate = outputDelegate
        super.init(nibName: "___VARIABLE_moduleName___ViewController", bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        return nil
    }

    override func initialComponents() {
        self.observeReactiveDatas()
    }

    override func registerEvents() {

    }

    private func observeReactiveDatas() {
        observeViewState()
        observeActionState()
        listenErrorState()
    }

    private func observeViewState() {
        viewModel.viewState.sink(receiveValue: { [weak self] states in
            guard let self = self, let states = states else { return }

            switch states {
            case .showNativeProgress(let isProgress):
                self.playNativeLoading(isLoading: isProgress)

            }

        }).store(in: &cancelBag)
    }

    private func listenErrorState() {
        observeErrorState(errorState: viewModel.errorState)
    }

    // MARK: Define Components
}

// MARK: Props
private extension ___VARIABLE_moduleName___ViewController {
    
}
