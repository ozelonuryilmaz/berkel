//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright (c) ___YEAR___ Berkel IOS Development Team. All rights reserved.[OY-2024]
//

import UIKit

protocol I___VARIABLE_moduleName___Coordinator: AnyObject {
    
}

final class ___VARIABLE_moduleName___Coordinator: PresentationCoordinator/NavigationCoordinator , I___VARIABLE_moduleName___Coordinator {

    private var coordinatorData: ___VARIABLE_moduleName___PassData { return castPassData(___VARIABLE_moduleName___PassData.self) }
    
    private weak var outputDelegate: ___VARIABLE_moduleName___ViewControllerOutputDelegate? = nil

    @discardableResult
    func with(outputDelegate: ___VARIABLE_moduleName___ViewControllerOutputDelegate) -> ___VARIABLE_moduleName___Coordinator {
        self.outputDelegate = outputDelegate
        return self
    }

     override func start() {
        guard let outputDelegate = outputDelegate else { return }
         
        let controller = ___VARIABLE_moduleName___Builder.generate(with: coordinatorData, 
                                                                   coordinator: self,
                                                                   outputDelegate: outputDelegate)
        
        // navigationController.pushViewController(controller, animated: true) // navigationCoordinator ise

        /*
         // presentation NavController ise
        let navController = MainNavigationController()
        navController.setRootViewController(viewController: controller)

         // presentation coordinator ise
        startPresent(targetVC: controller)
        */
     }
}

/*
 // Presenter
 extension ___VARIABLE_moduleName___Coordinator {

     static func getInstance(presenterViewController: UIViewController?) -> ___VARIABLE_moduleName___Coordinator {
         return ___VARIABLE_moduleName___Coordinator(presenterViewController: presenterViewController)
     }
 }

 */
