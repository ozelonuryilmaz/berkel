//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright (c) ___YEAR___ Berkel IOS Development Team. All rights reserved.[OY-2024]
//

import Foundation
import Combine

protocol I___VARIABLE_moduleName___ViewModel: AnyObject {

    var viewState: ScreenStateSubject<___VARIABLE_moduleName___ViewState> { get }
    var errorState: ErrorStateSubject { get }

    init(repository: I___VARIABLE_moduleName___Repository,
         coordinator: I___VARIABLE_moduleName___Coordinator,
         uiModel: I___VARIABLE_moduleName___UIModel)
}

final class ___VARIABLE_moduleName___ViewModel: BaseViewModel, I___VARIABLE_moduleName___ViewModel {

    // MARK: Definitions
    private let repository: I___VARIABLE_moduleName___Repository
    private let coordinator: I___VARIABLE_moduleName___Coordinator
    private var uiModel: I___VARIABLE_moduleName___UIModel

    // MARK: Private Props
    private let viewState = ScreenStateSubject<___VARIABLE_moduleName___ViewState>()
    var errorState = ErrorStateSubject(nil)
    //let response = CurrentValueSubject<?, Never>(nil)

    // MARK: Initiliazer
    required init(repository: I___VARIABLE_moduleName___Repository,
                  coordinator: I___VARIABLE_moduleName___Coordinator,
                  uiModel: I___VARIABLE_moduleName___UIModel) {
        self.repository = repository
        self.coordinator = coordinator
        self.uiModel = uiModel
    }

}


// MARK: Service
internal extension ___VARIABLE_moduleName___ViewModel {

}

// MARK: States
internal extension ___VARIABLE_moduleName___ViewModel {

    // MARK: View State
    func viewStateShowNativeProgress(isProgress: Bool) {
        viewState.value = .showNativeProgress(isProgress: isProgress)
    }

}

// MARK: Coordinate
internal extension ___VARIABLE_moduleName___ViewModel {

}

enum ___VARIABLE_moduleName___ViewState {
    case showLoadingProgress(isProgress: Bool)
}
